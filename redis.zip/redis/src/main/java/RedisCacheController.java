import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RedisCacheController {

    @GetMapping("/redisTest")
    public boolean test() {
        Caching.cacheData(Math.random());
        return false;
    }

}
