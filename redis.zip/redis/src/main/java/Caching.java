import org.springframework.cache.annotation.Cacheable;

public class Caching {


    @Cacheable(value = "boolean", key = "#random")
    public static boolean cacheData(double random) {
        if(random>100) {
            return false;
        }
        return true;
    }
}
